/******************** (C) COPYRIGHT 2010 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : MCD Application Team
* Version            : V1.3.1
* Date               : 07/23/2010
* Description        : read me file for Virtual COM Port driver 
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

Last version 
***************

       - V1.3.1 - 07/23/2010


Supported OS
***************

       + Windows 98SE, 2000, XP, Vista, Seven (x86 & x64 Windows platforms)
 

How to use 
***************

       1- Uninstall previous versions (Start-> Settings-> Control Panel-> Add or remove programs)

       2- run setup.
          


******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE******

