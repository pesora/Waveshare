/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : STMFlashLoader.cpp
* Author             : MCD Application Team
* Version            : V1.1.1
* Date               : 06/16/2008
* Description        : Defines the entry point for the console application
The enclosed software and all the related documentation
*                      are not covered by a License Agreement, if you need such
*                      License you can contact your local STMicroelectronics
*                      office.
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

#include "stdafx.h"
#include "string.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include<dos.h>

#include "../STBLLIB/STBLLIB.h"
#include "../Files/Files.h"

#define NONE = 0;
#define ODD  = 1;
#define EVEN = 2;

typedef enum STATE {OK,KO};

PMAPPING pMapping;
COORD pos = {0, 0};
char oldmsg[256];

int TimeBO = 100;

BOOL SHOW_OK = TRUE;  // Set to TRUE/FALSE to show/hide OK status  messages
BOOL SHOW_KO = TRUE;  // Set to TRUE/FALSE to show/hide KO status  messages


bool FileExist( LPCTSTR filename )
{
	// Data structure for FindFirstFile
	WIN32_FIND_DATA findData;

	// Clear find structure
	ZeroMemory(&findData, sizeof(findData));

	// Search the file
	HANDLE hFind = FindFirstFile( filename, &findData );
	if ( hFind == INVALID_HANDLE_VALUE )
	{
	// File not found
	return false;
	}

	// File found

	// Release find handle
	FindClose( hFind );
	hFind = NULL;

	// The file exists
	return true;
}


void man()
{
	printf("STMicroelectronics Flash Loader command line v1.0 \n\n");
	printf(" Usage : \n");
	printf("    STMFlashLoader.exe [options] [Agrument][[options] [Agrument]...] \n\n");
    
	printf("     -?                     (Show this help) \n");
	printf("     -c                     (establish connection to the COM port) \n");
	printf("       --pn  port_number    (e.g 1, 2 ..., default 1) \n");
	printf("       --br  baud_reate     (e.g 115200, 57600 ..., default 57600) \n");
	printf("       --db  data_bits      (value in {5,6,7,8} ..., default 8) \n");
	printf("       --pr  parity         (value in {NONE,ODD,EVEN} ..., default EVEN) \n");
	printf("       --sb  stop_bits      (value in {1,1.5,2} ..., default 1) \n");
	printf("       --to  time_out       ((ms) e.g 1000, 2000, 3000 ..., default 5000) \n");

	printf("     -i  device_name        (e.g STM32F10xxBxx, STM32F10xx8xx, STM32F10xx6xx [map file names in the Map directory]) \n");
	printf("     -e                     (erase flash pages\n");
	printf("       --all all pages      (erase all pages\n");
	printf("       --sec number_of pages_group pages_group_codes (erase specified group pages e.g 1,2,3,...) \n");

	printf("     -u                     (upload flash contents to the specified file (bin, hex or s19 file; the file type is recognized by its extension))\n");
	printf("       --fn  file_name      (full path name) \n");

	printf("     -d                     (download the conent of the specified file into MCU flash) \n");
	printf("       --a   address(hex)   (start addres; ignored if the target file is not a binary file) \n");
	printf("       --fn  file_name      (full path name (bin, hex or s19 file; the file type is recognized by its extension)) \n");
	printf("       --v                  (verify after download) \n");
	printf("       --o                  (optimize; removes FFs data)\n");

    printf("     -o                     (get or set option bytes \n");
	printf("       --get --fn file_name (get option bytes from the device and write it in the specified file) \n");
	printf("       --set --fn file_name (load option bytes from the specified file and write it to the device) \n");
	printf("       --set --vals --OPB hex_val (set the specified option byte; OPB in (User, RDP, Data0, Data1, WRP0, WRP1, WRP2, WRP3) \n");

	printf("     -p                     (activate or disactivate protection) \n");
	printf("       --erp                (enable read protection, all options following this one will fail) \n");
	printf("       --drp                (disable read protection) \n");
	printf("       --ewp                (enable write protection) for sector codes (e.g 1,2,3,...) \n");
	printf("       --dwp                (disable write protection) \n");

	printf("     -r                     (run the flash code at the specified address \n");
	printf("       --a address(hex)     (address) \n");
}

int ParityToInt(char* parity)
{
   if (strcmp(parity,"NONE")==0) return 0;
   else if(strcmp(parity,"ODD")==0) return 1;
   else if(strcmp(parity,"EVEN")==0) return 2;
   else return 2;
}

bool Is_Option(char* option)
{
	if (strcmp(option,"-?")==0) return true;
	if (strcmp(option,"-c")==0) return true;
	else if (strcmp(option,"-i")==0) return true;
	else if (strcmp(option,"-e")==0) return true;
	else if (strcmp(option,"-u")==0) return true;
	else if (strcmp(option,"-d")==0) return true;
	else if (strcmp(option,"-v")==0) return true;
	else if (strcmp(option,"-p")==0) return true;
	else if (strcmp(option,"-r")==0) return true;
	else if (strcmp(option,"-o")==0) return true;
    else return false;
}

bool Is_SubOption(char* suboption)
{
	if (strcmp(suboption,"--pn")==0) return true;  
	else if (strcmp(suboption,"--br")==0) return true;  
	else if (strcmp(suboption,"--db")==0) return true;  
	else if (strcmp(suboption,"--pr")==0) return true;  
	else if (strcmp(suboption,"--sb")==0) return true;  
	else if (strcmp(suboption,"--to")==0) return true;  
	else if (strcmp(suboption,"--lcs")==0) return true; 
	else if (strcmp(suboption,"--all")==0) return true; 
	else if (strcmp(suboption,"--sec")==0) return true; 
	else if (strcmp(suboption,"--a")==0) return true;
	else if (strcmp(suboption,"--s")==0) return true;
	else if (strcmp(suboption,"--fn")==0) return true;
	else if (strcmp(suboption,"--v")==0) return true;
	else if (strcmp(suboption,"--o")==0) return true;
	else if (strcmp(suboption,"--erp")==0) return true;
	else if (strcmp(suboption,"--drp")==0) return true;
	else if (strcmp(suboption,"--ewp")==0) return true;
	else if (strcmp(suboption,"--dwp")==0) return true;
	else if (strcmp(suboption,"--get")==0) return true;
	else if (strcmp(suboption,"--set")==0) return true;
	else if (strcmp(suboption,"--vals")==0) return true;
	else if (strcmp(suboption,"--RDP")==0) return true;
	else if (strcmp(suboption,"--User")==0) return true;
	else if (strcmp(suboption,"--Data0")==0) return true;
	else if (strcmp(suboption,"--Data1")==0) return true;
	else if (strcmp(suboption,"--WRP0")==0) return true;
	else if (strcmp(suboption,"--WRP1")==0) return true;
	else if (strcmp(suboption,"--WRP2")==0) return true;
	else if (strcmp(suboption,"--WRP3")==0) return true;

	else return false;
}

void write_debug_info(char *msg, int page, DWORD addr, float size, STATE status)
{

	/*if (strcmp(oldmsg , msg) != 0)
	{
		sprintf(oldmsg,msg);
		pos.Y++;
	}

	HANDLE hConsole = GetStdHandle ( STD_OUTPUT_HANDLE );

    if ( INVALID_HANDLE_VALUE != hConsole )
	{
       SetConsoleCursorPosition(hConsole, pos );
	}*/



	char d_info[256];

	if((page==0) && (addr==0) && (size==0))
	{
		if(status == OK) 
		   sprintf(d_info, "%s \t\t\t\t [OK] \n", msg);  
	    else 
		   sprintf(d_info, "%s \t\t\t\t [KO] \n", msg); 
	}
	else if(status == OK) 
		sprintf(d_info, "%s \t page %i \t @0x %8X \t size %.2f(Kb) \t [OK] \n", msg, page, addr, (float)size);  
	else 
		sprintf(d_info, "%s \t page %i \t @0x %8X \t size %.2f(Kb) \t [KO] \n", msg, page, addr, (float)size); 

	if((SHOW_OK && (status == OK)) || (SHOW_KO && (status == KO))) printf(d_info);
}

int main(int argc, char* argv[])
{
	/*if (STBL_GO(0x00000000) == SUCCESS)
    {
	}*/

    START:
	//system("cls");
	BYTE Res = SUCCESS;

	BYTE User; 
	BYTE RDP;
    BYTE Data0;
	BYTE Data1;
								   
	BYTE WRP0;
	BYTE WRP1;
	BYTE WRP2;
	BYTE WRP3;

	bool WaitForMoreSubOpt = true;

	int   portname = 1;
	long  BaudRate = 57600 ;
	int   DataBits = 8;
	int   parity   = ParityToInt("EVEN"); 
	double nbStopBit= 1;
	int   timeout  = 5000;

	int   nsec     = 0;
	DWORD address  = 0x00000000;
	DWORD size     = 0x00000000;
	char*  filename;
	char devname[256] = "STM32F10xx.STmap";
	bool Verify = false;
	BOOL optimize = FALSE;

	char Drive[3], Dir[256], Fname[256], Ext[256];
	char *ptr;

	if (argc == 1) man();
	else
	{
		int arg_index = 1;

		while(arg_index < argc)
		{
			/*if (arg_index< argc-1) arg_index++;
			else break;*/

			if(!Is_Option(argv[arg_index])) 
			{
			  if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
			  COM_Close(); getchar(); return 0;
			}

			if (strcmp(argv[arg_index],"-?")==0) 
			{
				man(); 
				return 0;
			}
			else if (strcmp(argv[arg_index],"-c")==0)
			{
			   //printf("connecting \n");

			   while(arg_index < argc)
			   {
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc-1) arg_index++;
			         else break;

					 if (strcmp(argv[arg_index-1],"--pn")==0)       portname = atoi(argv[arg_index]);//port name  (e.g COM1, COM2 ..., default COM1) \n");
					 else if (strcmp(argv[arg_index-1],"--br")==0)  BaudRate = atoi(argv[arg_index]);//baud reate (e.g 115200, 128000 ..., default 115200) \n");
					 else if (strcmp(argv[arg_index-1],"--db")==0)  DataBits = atoi(argv[arg_index]);//data bits  (in {5,6,7,8} ..., default 8) \n");
					 else if (strcmp(argv[arg_index-1],"--pr")==0)  parity   = ParityToInt(argv[arg_index]); //parity     (in {NONE,ODD,EVEN} ..., default EVEN) \n");
					 else if (strcmp(argv[arg_index-1],"--sb")==0)  nbStopBit= atof(argv[arg_index]);//stop bits  (in {1,1.5,2} ..., default 1) \n");
					 else if (strcmp(argv[arg_index-1],"--to")==0)  timeout  = atoi(argv[arg_index]);//time out   (e.g 1000, 2000, 3000 ..., default 5) \n");
				 }
				 else 
				 {
                     if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }

			   SetCOMSettings(portname, BaudRate, DataBits, parity, nbStopBit);
			   Res = COM_Open();
			   SetTimeOut(1000);

			   if ((Res != SUCCESS) && (Res != COM_ALREADY_OPENED)) 
			   {
				    write_debug_info("Connecting", 0 ,0, 0, KO);
					printf("Cannot open the com port, the port may \n be used by another application \n");
					COM_Close(); getchar(); return 0;
			   }

			   write_debug_info("Connecting", 0 ,0, 0, OK);


			   Res = STBL_Init_BL();
			   if (Res == UNREOGNIZED_DEVICE)
			   {
				    write_debug_info("Configuring", 0 ,0, 0, KO);
			 	    COM_Close();
					printf("Unrecognized device... Please, reset your device then try again \n");
					COM_Close(); 
					
					printf("Please, reset your device then then perss any key to continue \n");
					getchar();
					goto START;
			   }
			   else if (Res != SUCCESS) 		
			   {
				   write_debug_info("Configuring", 0 ,0, 0, KO);
					COM_Close();
					printf("No response from the target, the Boot loader can not be started. \nPlease, verify the boot mode configuration, reset your device then try again. \n");
					COM_Close(); 
					
					printf("Please, reset your device then then perss any key to continue \n");
					getchar();
					goto START;
			   }

			   _sleep(TimeBO);
			   write_debug_info("Configuring", 0 ,0, 0, OK);

			   BYTE Version ;
			   Commands pCmds;
			   Res = STBL_GET(&Version, &pCmds);
		       if (Res != SUCCESS)
			   {
					//printf("cannot Get BL available commands");
					COM_Close(); getchar(); return 0; 
			   }

			   SetTimeOut(timeout);
			}
			else if (strcmp(argv[arg_index],"-e")==0)
			{
			   //printf("erasing \n");

			   while(arg_index < argc)
			   {

				 if (!WaitForMoreSubOpt) break;
				 
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 if (strcmp(argv[arg_index-1],"--all")==0)   
					 {
						 WaitForMoreSubOpt = false;

						 //printf("erasing all pages OK \n");
						 Res = STBL_ERASE(0xFF, NULL);
						 if (Res != SUCCESS) write_debug_info("erasing all pages", 0 ,0, 0, KO);
						 else write_debug_info("erasing all pages", 0 ,0, 0, OK);
					 }
					 else if (strcmp(argv[arg_index-1],"--sec")==0) 
					 {
						 WaitForMoreSubOpt = true;

						 nsec = atoi(argv[arg_index]);
						 LPBYTE sectors = (LPBYTE)malloc(nsec + 1);


					 	 sectors[0] = 0;
				 		 for(int i = 1; i<= nsec; i++)
						 {
							sectors[0]++;
							arg_index++;
							sectors[sectors[0]] = atoi(argv[arg_index]);
						 }

						 WaitForMoreSubOpt = false;

						 //printf("erasing pages OK \n");
						 Res = STBL_ERASE(nsec, sectors+1);
						 if (Res != SUCCESS)  
						 {
							 write_debug_info("erasing", 0 ,0, 0, KO);
							 COM_Close(); getchar(); return 0;
						 }
						 else write_debug_info("erasing", 0 ,0, 0, OK);

						 arg_index++;
					 }
				 }
				 else 
				 {
                     if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }
			}
			else if (strcmp(argv[arg_index],"-u")==0)
			{
				//printf("uploading \n");

				while(arg_index < argc)
				{
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 /*if (strcmp(argv[arg_index-1],"--a")==0)   
					 {
						 address = _tcstoul(argv[arg_index], 0, 16) ;
					 }
					 else if (strcmp(argv[arg_index-1],"--s")==0) 
					 {
						 size = _tcstoul(argv[arg_index], 0, 16) ;
					 }
					 else */if (strcmp(argv[arg_index-1],"--fn")==0) 
					 {
						 filename = argv[arg_index];
					 }
				 }
				 else 
				 {
                     if (arg_index< argc) if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }

			   HANDLE Handle;
			   FILES_CreateImage(&Handle, 0);

			   FILES_CreateImageFromMapping(&Handle,pMapping);

			   DWORD NbElements = 0;
               if (FILES_GetImageNbElement(Handle, &NbElements) == FILES_NOERROR)
			   {
				   if (NbElements > 0)
				   {
							for(int i = 0; i< (int)NbElements; i++)
							{
								IMAGEELEMENT Element={0};
								// Get element data size
								if (FILES_GetImageElement(Handle, i, &Element) == FILES_NOERROR)
								{
									//Upload element data
									Element.Data = (LPBYTE)malloc(Element.dwDataLength);
									if (STBL_UPLOAD(Element.dwAddress, Element.Data, Element.dwDataLength) == SUCCESS)
									{
									   //Insert elment in the Image
									   write_debug_info("Uploading", i ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, OK);
									   FILES_SetImageElement(Handle,i,FALSE,Element);
									}
									else 
									{
										write_debug_info("Uploading", i ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, KO);
										COM_Close(); getchar(); return 0;
									}
								}
							}
				   }
			   }

			   //printf("Upload [OK] \n");

			   if(!FileExist((LPCTSTR)filename))
			   {
                      printf( "file does not exist %s \n", filename);
					  COM_Close(); getchar(); return 0;
			   }

			   if (FILES_ImageToFile((LPSTR)(LPCSTR)filename,Handle) == SUCCESS)
			   {
                      printf( "cannot open file %s \n", filename);
					  COM_Close(); getchar(); return 0;
			   }

			   //printf( "Uploaded data saved to %s \n", filename);

			}
			else if (strcmp(argv[arg_index],"-i")==0)
			{
			   if (arg_index< argc) arg_index++;
			   else break;

			   sprintf(devname,"%s.STmap", argv[arg_index]);

			   char Drive[3], Dir[256], Fname[256], Ext[256];
			   _splitpath(argv[0],Drive,Dir,Fname,Ext);
					
			   char MapFile[256];
			   sprintf(MapFile, "%s%s%s%s", Drive, Dir , "Map\\", devname);

			   pMapping = NULL;
			   WORD size = 0;

			   WORD PacketSize = 0;
			   pMapping = NULL;
			   WORD Size = 0;
			   char MapName[256]; 
			   // Get the number of sectors in the flash target: pMapping should be NULL
			   // number of sectors is returned in the Size value
			   BYTE PagePerSector = 0;

			   if (!FileExist((LPCTSTR)MapFile))
			   {
				   printf("This version is not intended to support the <%s> target\n", argv[arg_index]);
				   COM_Close();
				   getchar();
				   return 0;
			   }

			   FILES_GetMemoryMapping((LPSTR)(LPCTSTR)MapFile, &Size, (LPSTR)MapName, &PacketSize, pMapping, &PagePerSector);
			   // Allocate the mapping structure memory
			   pMapping = (PMAPPING)malloc(sizeof(MAPPING));
			   pMapping->NbSectors = 0;
			   pMapping->pSectors = (PMAPPINGSECTOR) malloc((Size) * sizeof(MAPPINGSECTOR));

			   // Get the mapping info
			   FILES_GetMemoryMapping((LPSTR)(LPCTSTR)MapFile, &Size, (LPSTR)(LPCTSTR)MapName, &PacketSize, pMapping, &PagePerSector);
				   
			   SetPaketSize(PacketSize);

				if (arg_index< argc) arg_index++;
			    else break;
			}
			else if (strcmp(argv[arg_index],"-d")==0)
			{
				while(arg_index < argc)
				{
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 if (strcmp(argv[arg_index-1],"--a")==0)   
					 {
						 address = _tcstoul(argv[arg_index], 0, 16) ;
					 }
					 else if (strcmp(argv[arg_index-1],"--v")==0) 
					 {
						 Verify = true;
						 arg_index--;
					 }
					 else if (strcmp(argv[arg_index-1],"--o")==0) 
					 {
						 optimize = TRUE;
						 arg_index--;
					 }
					 else if (strcmp(argv[arg_index-1],"--fn")==0) 
					 {
						 filename = argv[arg_index];
						 _splitpath(filename,Drive,Dir,Fname,Ext);
	                     ptr=strupr(Ext);
	                     strcpy(Ext, ptr);
					 }
				 }
				 else 
				 {
                     if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }

			   PMAPPINGSECTOR pSector = pMapping->pSectors;
			   for(int i = 1; i<= (int)pMapping->NbSectors; i++)
			   {
				   if ((strcmp(Ext, ".BIN")!=0) && (i==0))
			          address = pSector->dwStartAddress;

			       pSector->UseForOperation = TRUE;
			       pSector++;
			   }

			   if(!FileExist((LPCTSTR)filename))
			   {
                      printf( "file does not exist %s \n", filename);
					  COM_Close(); getchar(); return 0;
			   }

			   HANDLE Handle;
			   if (FILES_ImageFromFile((LPSTR)(LPCSTR)filename,&Handle, 1) == FILES_NOERROR)
			   {
			      FILES_SetImageName(Handle,(LPSTR)(LPCSTR)filename);

				  DWORD NbElements = 0;
				  if (FILES_GetImageNbElement(Handle, &NbElements) == FILES_NOERROR)
				  {
						if ( NbElements > 0 )
						{   // if binary file -> change the elemnts address
							if (strcmp(Ext, ".BIN")==0)
							{
								for (int i=0;i< (int)NbElements;i++)
								{
									IMAGEELEMENT Element={0};
									if (FILES_GetImageElement(Handle, i, &Element) == FILES_NOERROR)
									{
									   Element.Data= (LPBYTE)malloc(Element.dwDataLength);
									   if (FILES_GetImageElement(Handle, i, &Element) == FILES_NOERROR)
									   {
										   Element.dwAddress = Element.dwAddress + address; 
										   FILES_SetImageElement(Handle, i, FALSE, Element);
									   }
									}
								}
							}
						}
				  }

				  FILES_FilterImageForOperation(Handle, pMapping, OPERATION_UPLOAD, optimize);
			   }
			   else 
			   {  
				   printf("cannot open file %s \n", filename);
				   COM_Close(); getchar(); return 0;
			   }

			   DWORD NbElements = 0;
               if (FILES_GetImageNbElement(Handle, &NbElements) == FILES_NOERROR)
			   {
				   for (int el=0; el< (int)NbElements;el++)
				   {
						IMAGEELEMENT Element={0};
						if (FILES_GetImageElement(Handle, el, &Element) == FILES_NOERROR)
						{	   
						   Element.Data= (LPBYTE)malloc(Element.dwDataLength);
						   if (FILES_GetImageElement(Handle, el, &Element) == FILES_NOERROR)
						   {
							  if ((strcmp(Ext, ".BIN")==0) && (el==0)) 
							      Element.dwAddress = address;
							  
							  if (STBL_DNLOAD(Element.dwAddress, Element.Data, Element.dwDataLength, false /*Optimize*/) != SUCCESS)
							  {
								  write_debug_info( "downloading", el ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, KO);
								  write_debug_info("Th flash may be read protected; use -p --drp to disable write protection." , 0, 0, 0, KO);
								  COM_Close(); getchar(); return 0;
							  }

							  write_debug_info( "downloading", el ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, OK);
						   }
						}
				   }
			   }

			   bool VerifySuccess = true;
			   if (Verify)
			   {
					for (int el=0; el< (int)NbElements;el++)
					{
						IMAGEELEMENT Element={0};
					    if (FILES_GetImageElement(Handle, el, &Element) == FILES_NOERROR)
						{
							Element.Data=(LPBYTE)malloc(Element.dwDataLength);
							if (FILES_GetImageElement(Handle, el, &Element) == FILES_NOERROR)
							{
								if ((strcmp(Ext, ".BIN")==0) && (el==0)) 
							        Element.dwAddress = address;

								if (STBL_VERIFY(Element.dwAddress, Element.Data, Element.dwDataLength, false /*Optimize*/) != SUCCESS)
								{
									VerifySuccess = false;
									write_debug_info("verifying" ,el ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, KO);
                                    write_debug_info("some pages may be write protected; use -p --dwp to disable write protection." , 0, 0, 0, KO);
									COM_Close(); getchar(); return 0;
								}

								write_debug_info("verifying" ,el ,Element.dwAddress, (float)Element.dwDataLength/(float)1024, OK);
							}
						}
					}
			   }

			}
			else if (strcmp(argv[arg_index],"-v")==0)
			{
				//printf("verifying \n");
				if (arg_index< argc) arg_index++;
			    else break;
			}
			else if (strcmp(argv[arg_index],"-o")==0)
			{
				while(arg_index < argc)
				{
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 if (strcmp(argv[arg_index-1],"--get")==0) 
					 {
						 if (arg_index< argc) arg_index++;
			             else break;
                           
                         if (strcmp(argv[arg_index-1],"--fn")==0) 
					       filename = argv[arg_index];
						 
						 if(TARGET_GetSIFData(&User, &RDP, &Data0, &Data1, &WRP0, &WRP1, &WRP2, &WRP3) == SUCCESS)
						 {
						   write_debug_info("Getting Option bytes  data" ,0 ,0, 0, OK);

					       HANDLE Image;
						   if (FILES_CreateImage(&Image, 1) == FILES_NOERROR)
						   {
								IMAGEELEMENT Element={0};
								Element.dwAddress   = 0x1FFFF800;
								Element.dwDataLength = 16;
								Element.Data = (LPBYTE)malloc(Element.dwDataLength);

								{
									Element.Data[0]  = RDP;
									Element.Data[1]  = ~RDP;
									Element.Data[2]  = User;
									Element.Data[3]  = ~User;
									Element.Data[4]  = Data0;
									Element.Data[5]  = ~Data0;
									Element.Data[6]  = Data1;
									Element.Data[7]  = ~Data1;
									Element.Data[8]  = WRP0;
									Element.Data[9]  = ~WRP0;
									Element.Data[10] = WRP1;
									Element.Data[11] = ~WRP1;
									Element.Data[12] = WRP2;
									Element.Data[13] = ~WRP2;
									Element.Data[14] = WRP3;
									Element.Data[15] = ~WRP3;
								}

								FILES_SetImageElement(Image,0,TRUE,Element);
								if (FILES_ImageToFile((LPSTR)(LPCSTR)filename,Image) != FILES_NOERROR)
								{
								    write_debug_info("Saving Option bytes  data",0 ,0, 0, KO);
								}
								else  write_debug_info("Saving Option bytes  data",0 ,0, 0, OK); 
						   }
						 }
						 else write_debug_info("Getting Option bytes  data" ,0 ,0, 0, KO);
					 }
					 else if (strcmp(argv[arg_index-1],"--set")==0) 
					 {
						 if (arg_index< argc) arg_index++;
			             else break;
                           
                         if (strcmp(argv[arg_index-1],"--fn")==0) 
						 {
					           filename = argv[arg_index];

							   HANDLE OPBImage;

							   if(!FileExist((LPCTSTR)filename))
							   {
									  printf( "file does not exist %s \n", filename);
									  COM_Close(); getchar(); return 0;
							   }

							   if (FILES_ImageFromFile((LPSTR)(LPCSTR)filename, &OPBImage, 0) == FILES_NOERROR)
							   {
								   DWORD NbElements = 0;
								   if (FILES_GetImageNbElement(OPBImage, &NbElements) == FILES_NOERROR)
								   {
									   if ( NbElements == 1 )
									   {
										  IMAGEELEMENT Element={0};
										  if (FILES_GetImageElement(OPBImage, 0, &Element) == FILES_NOERROR)
										  {
											  Element.Data= (LPBYTE)malloc(Element.dwDataLength);
											  if (FILES_GetImageElement(OPBImage, 0, &Element) == FILES_NOERROR)
											  {
												  RDP   = Element.Data[0] ;
												  User  = Element.Data[2] ;
												  Data0 = Element.Data[4] ;
												  Data1 = Element.Data[6] ;
												  WRP0  = Element.Data[8] ;
												  WRP1  = Element.Data[10];
												  WRP2  = Element.Data[12];
												  WRP3  = Element.Data[14];

												  
												  if (TARGET_SetSIFData(User, RDP, Data0, Data1, WRP0, WRP1, WRP2, WRP3) == SUCCESS)
												  {
													  write_debug_info("Setting Option bytes  data" ,0 ,0, 0, OK);

													  COM_Close();
													  COM_Open();

													  if(STBL_Init_BL() != SUCCESS) write_debug_info("Resetting device" ,0 ,0, 0, KO);
													  else write_debug_info("Resetting device" ,0 ,0, 0, OK);
												  }
												  else write_debug_info("Setting Option bytes  data" ,0 ,0, 0, KO);
											  }
										  }
									   }
								   }
							   }
						 }
						 else if (strcmp(argv[arg_index-1],"--vals")==0) 
						 {
							   TARGET_GetSIFData(&User, &RDP, &Data0, &Data1, &WRP0, &WRP1, &WRP2, &WRP3);
                               while(arg_index< argc)
							   {
								   if(Is_Option(argv[arg_index])) break;
				                   else if(Is_SubOption(argv[arg_index]))
								   {
									   arg_index++;
									   if(strcmp(argv[arg_index-1],"--RDP")==0)       { RDP   = _tcstoul(argv[arg_index], 0, 16);arg_index++;}
									   else if(strcmp(argv[arg_index-1],"--User")==0) { User  = _tcstoul(argv[arg_index], 0, 16);arg_index++;} 
									   else if(strcmp(argv[arg_index-1],"--data0")==0){ Data0 = _tcstoul(argv[arg_index], 0, 16);arg_index++;}
									   else if(strcmp(argv[arg_index-1],"--data1")==0){ Data1 = _tcstoul(argv[arg_index], 0, 16);arg_index++;} 
									   else if(strcmp(argv[arg_index-1],"--WRP0")==0) { WRP0  = _tcstoul(argv[arg_index], 0, 16);arg_index++;} 
									   else if(strcmp(argv[arg_index-1],"--WRP1")==0) { WRP1  = _tcstoul(argv[arg_index], 0, 16);arg_index++;}
									   else if(strcmp(argv[arg_index-1],"--WRP2")==0) { WRP2  = _tcstoul(argv[arg_index], 0, 16);arg_index++;}
									   else if(strcmp(argv[arg_index-1],"--WRP3")==0) { WRP3  = _tcstoul(argv[arg_index], 0, 16);arg_index++;}
								   }
							   }
                               if (TARGET_SetSIFData(User, RDP, Data0, Data1, WRP0, WRP1, WRP2, WRP3) != SUCCESS)
								   write_debug_info("Setting Option bytes  data" ,0 ,0, 0, KO);
							   else
							   {
								    write_debug_info("Setting Option bytes  data" ,0 ,0, 0, OK);

									COM_Close();
									COM_Open();

									if(STBL_Init_BL() != SUCCESS) write_debug_info("Resetting device" ,0 ,0, 0, KO);
									else write_debug_info("Resetting device" ,0 ,0, 0, OK);
							   }
							   arg_index--;
						 }
					 }
				 }
				 else 
				 {
                     if (arg_index< argc) if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }
			}
			else if (strcmp(argv[arg_index],"-p")==0)
			{
				while(arg_index < argc)
				{
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 if (strcmp(argv[arg_index-1],"--erp")==0) 
					 {
						 if(STBL_READOUT_PROTECT() != SUCCESS) write_debug_info( "enabling read protection", 0 , 0, 0, KO);
						 else write_debug_info( "enabling read protection", 0 , 0, 0, OK);
					
						 _sleep(TimeBO);

		                 if(STBL_Init_BL() != SUCCESS) write_debug_info( "reseting device", 0 , 0, 0, KO);
						 else write_debug_info( "reseting device", 0 , 0, 0, OK);
						 arg_index--;
						 //break;
					 }
					 else if (strcmp(argv[arg_index-1],"--drp")==0) 
					 {
						 if(STBL_READOUT_PERM_UNPROTECT() == SUCCESS) 
						 {
							 write_debug_info( "disabling read protection", 0 , 0, 0, OK);

							 _sleep(TimeBO);

		                     if(STBL_Init_BL() != SUCCESS) write_debug_info( "reseting device", 0 , 0, 0, KO);
						     else write_debug_info( "reseting device", 0 , 0, 0, OK);
						 }
						 else write_debug_info( "disabling read protection", 0 , 0, 0, KO);
						 
						 arg_index--;
						 //break;
					 }
					 else if (strcmp(argv[arg_index-1],"--ewp")==0) 
					 {
						 LPBYTE sectors;
						 if(Is_Option(argv[arg_index])) break;

						 nsec = atoi(argv[arg_index]);
						 sectors = (LPBYTE)malloc(nsec + 1);


					 	 sectors[0] = 0;
				 		 for(int i = 1; i<= nsec; i++)
						 {
								sectors[0]++;
								arg_index++;
								sectors[sectors[0]] = atoi(argv[arg_index]);
						 }

						 if(STBL_WRITE_PROTECT(((LPBYTE)sectors)[0],&((LPBYTE)sectors)[1]) != SUCCESS) write_debug_info( "enabling write protection", 0 , 0, 0, KO);
						 else write_debug_info( "enabling write protection", 0 , 0, 0, OK);
						 
						 _sleep(TimeBO);

		                 if(STBL_Init_BL() != SUCCESS) write_debug_info( "reseting device", 0 , 0, 0, KO);
						 else write_debug_info( "reseting device", 0 , 0, 0, OK);
						 //break;
					 }
					 else if (strcmp(argv[arg_index-1],"--dwp")==0) 
					 {
						 if(STBL_WRITE_PERM_UNPROTECT() != SUCCESS) write_debug_info( "disabling write protection", 0 , 0, 0, KO);
						 else write_debug_info( "disabling write protection", 0 , 0, 0, OK);
						 
						 _sleep(TimeBO);

		                 if(STBL_Init_BL() != SUCCESS) write_debug_info( "reseting device", 0 , 0, 0, KO);
						 else write_debug_info( "reseting device", 0 , 0, 0, OK);
						 arg_index--;
						 //break;
					 }
				 }
				 else 
				 {
                     if (arg_index< argc) if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }
			   }
			}
			else if (strcmp(argv[arg_index],"-r")==0)
			{
				//printf("running \n");
				while(arg_index < argc)
				{
			     if (arg_index< argc-1) arg_index++;
			     else break;

				 if(Is_Option(argv[arg_index])) break;
				 else if(Is_SubOption(argv[arg_index]))
				 {
					 if (arg_index< argc) arg_index++;
			         else break;

					 PMAPPINGSECTOR pSector = pMapping->pSectors;
				     address = pSector->dwStartAddress;

					 if (strcmp(argv[arg_index-1],"--a")==0)   
					 {
						 address = _tcstoul(argv[arg_index], 0, 16) ;
					 }
				 }
				 else 
				 {
                     if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
					 break;
				 }

				 if (STBL_GO(address) == SUCCESS)
				 {
					 printf("Your code is running...\n");
				 }
				 else
				 {
					 printf( "run fails \n");
				 }
			   }
			}
			else
			{
				if (arg_index < argc - 1) printf("bad parameter [%s] \n", argv[arg_index]);
				COM_Close(); 
	            getchar();
	            return 1;
			}
		}
	}

   
	COM_Close(); 
	printf("command executes succesfully, press any key to exit");
	getchar();
	return 1;
}


/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE******/
