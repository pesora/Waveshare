/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : Errors.h
* Author             : MCD Application Team
* Version            : V1.1.1
* Date               : 06/16/2008
* Description        : Defines the files Input/Output error codes
*                      The enclosed software and all the related documentation
*                      are not covered by a License Agreement, if you need such
*                      License you can contact your local STMicroelectronics
*                      office.
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

#ifndef ERRORS_H
#define ERRORS_H

#define FILES_ERROR_OFFSET				(0x12340000+0x6000)

#define FILES_NOERROR					(0x12340000+0x0000)
#define FILES_BADSUFFIX				    (FILES_ERROR_OFFSET+0x0002)
#define FILES_UNABLETOOPENFILE			(FILES_ERROR_OFFSET+0x0003)
#define FILES_UNABLETOOPENTEMPFILE		(FILES_ERROR_OFFSET+0x0004)
#define FILES_BADFORMAT				    (FILES_ERROR_OFFSET+0x0005)
#define FILES_BADADDRESSRANGE			(FILES_ERROR_OFFSET+0x0006)
#define FILES_BADPARAMETER				(FILES_ERROR_OFFSET+0x0008)
#define FILES_UNEXPECTEDERROR			(FILES_ERROR_OFFSET+0x000A)	
#define FILES_FILEGENERALERROR			(FILES_ERROR_OFFSET+0x000D)

#define STPRT_ERROR_OFFSET				(0x12340000+0x5000)

#define STPRT_NOERROR					(0x12340000)
#define STPRT_UNABLETOLAUNCHTHREAD	(STPRT_ERROR_OFFSET+0x0001)
#define STPRT_ALREADYRUNNING			(STPRT_ERROR_OFFSET+0x0007)
#define STPRT_BADPARAMETER				(STPRT_ERROR_OFFSET+0x0008)
#define STPRT_BADFIRMWARESTATEMACHINE	(STPRT_ERROR_OFFSET+0x0009)	
#define STPRT_UNEXPECTEDERROR			(STPRT_ERROR_OFFSET+0x000A)	
#define STPRT_ERROR					(STPRT_ERROR_OFFSET+0x000B)	
#define STPRT_RETRYERROR					(STPRT_ERROR_OFFSET+0x000C)	
#define STPRT_UNSUPPORTEDFEATURE		    (STPRT_ERROR_OFFSET+0x000D)	

#endif

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE******/