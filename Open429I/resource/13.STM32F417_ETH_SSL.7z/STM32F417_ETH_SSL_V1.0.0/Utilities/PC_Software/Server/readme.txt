This directory contains:

1- ssl_server.exe: it is a part of PolarSSL-0.12.0 examples. 
   It has been build under Visual Studio 6.0 with debug option set to zero.

2- db_ssl_server.exe: it is a part of PolarSSL-0.12.0 examples.
   It has been build under Visual Studio 6.0 with debug option set to higher level.


